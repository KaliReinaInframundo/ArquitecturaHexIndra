package com.example.hexagonal.application.ports;

import com.example.hexagonal.model.Orders;

import java.util.List;
import java.util.Optional;

public interface OrderRepository {

    Orders save(Orders orders);

    List<Orders> findAll();

    Optional<Orders> findById(Long id);

    void deleteById(Long id);
}
