package com.example.hexagonal.application.service;

import com.example.hexagonal.application.ports.OrderRepository;
import com.example.hexagonal.model.Orders;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.List;
import java.util.Optional;

@ApplicationScoped
public class OrderService {

    @Inject
    OrderRepository orderRepository;

    public OrderService(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    public Orders createOrder(Orders order) {
        return orderRepository.save(order);
    }

    public Optional<Orders> getOrder(Long id) {
        return orderRepository.findById(id);
    }

    public List<Orders> getAllOrders() {
        return orderRepository.findAll();
    }

    public void deleteOrder(Long id) {
        orderRepository.deleteById(id);
    }

}
