package com.example.hexagonal.adapter;

import com.example.hexagonal.application.OrderService;
import com.example.hexagonal.domain.Orders;
import com.example.hexagonal.domain.OrderItem;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.List;

@Path("/orders")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class OrderResource {

    @Inject
    OrderService orderService;

    @POST
    public Response createOrder(Orders orders){
        orderService.createOrder(orders);
        return Response.status(Response.Status.CREATED).entity(orders).build();
    }

    @POST
    @Path("/{orderId}/items")
    public Response addItemToOrder(@PathParam("orderId") Long orderId, OrderItem item){
        orderService.addItemToOrder(orderId, item);
        return Response.ok().build();
    }

    @PUT
    @Path("/{orderId}/status")
    public Response updateOrderStatus(@PathParam("orderId") Long orderId, String status){
        orderService.updateOrderStatus(orderId, status);
        return Response.ok().build();
    }

    @GET
    public List<Orders> getAllOrders(){
        return orderService.getAllOrders();
    }

    @GET
    @Path("/{orderId}")
    public Orders getOrderById(@PathParam("orderId") Long orderId){
        return orderService.findOrderById(orderId);
    }


}
