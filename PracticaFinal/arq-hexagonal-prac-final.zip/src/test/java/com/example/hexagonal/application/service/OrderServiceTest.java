package com.example.hexagonal.application.service;

import com.example.hexagonal.application.ports.OrderRepository;
import com.example.hexagonal.domain.Orders;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class OrderServiceTest {

    @Mock
    OrderRepository orderRepository;

    @InjectMocks
    OrderService orderService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateOrder() {
        Orders order = new Orders(null, "In progress", null, new ArrayList<>());
        when(orderRepository.save(any(Orders.class))).thenReturn(order);

        Orders createdOrder = orderService.save(order);

        assertEquals(order.getStatus(), createdOrder.getStatus());
        verify(orderRepository, times(1)).save(order);
    }

    @Test
    void testGetAllOrdersByIdCostumer() {
        Orders order = new Orders(1L, "In progress", 1L, new ArrayList<>());
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));

        List<Orders> fetchedOrder = orderService.getAllOrdersByIdCustomer(1L);

        assertEquals(order.getStatus(), fetchedOrder.get(0).getStatus());
        verify(orderRepository, times(1)).findById(1L);
    }

    @Test
    void testGetAllOrders() {
        // similar to above, test for getAllOrders()
    }

    @Test
    void testDeleteOrder() {
        doNothing().when(orderRepository).deleteById(1L);

        orderService.deleteOrder(1L);

        verify(orderRepository, times(1)).deleteById(1L);
    }
}