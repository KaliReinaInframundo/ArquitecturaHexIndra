package com.example.hexagonal.adapter;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
class OrderResourceIT extends OrderResourceTest {
    // Execute the same tests but in packaged mode.
}
