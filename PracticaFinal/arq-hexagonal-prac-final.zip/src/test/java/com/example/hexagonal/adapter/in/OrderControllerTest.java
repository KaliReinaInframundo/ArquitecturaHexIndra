package com.example.hexagonal.adapter.in;

import com.example.hexagonal.application.service.OrderService;
import com.example.hexagonal.domain.Orders;
import io.quarkus.test.junit.QuarkusTest;
import io.restassured.RestAssured;
import jakarta.ws.rs.core.MediaType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Mockito.when;

@QuarkusTest
class OrderControllerTest {

    @Mock
    OrderService orderService;

    @InjectMocks
    OrderResource orderResource;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        RestAssured.config = RestAssured.config();
    }

    @Test
    void testCreateOrder() {
        Orders order = new Orders(null, "In Progress", null, new ArrayList<>());
        when(orderService.save(order)).thenReturn(order);

        given()
                .contentType(MediaType.APPLICATION_JSON)
                .body(order)
                .when()
                .post("/orders")
                .then()
                .statusCode(201)
                .body("id", is(order.getId()));
    }

    @Test
    void testGeAllOrdersByIdCustomer() {
        Orders order = new Orders(1L, "In progress", 1L, new ArrayList<>());
        when(orderService.getAllOrdersByIdCustomer(1L)).thenReturn(List.of(order));

        given()
                .pathParam("id", 1L)
                .when()
                .get("/orders/{id}")
                .then()
                .statusCode(200)
                .body("status", is("In progress"));
    }

    @Test
    void testGetAllOrders() {
        // similar to above, test for getAllOrders()
    }

    @Test
    void testDeleteOrder() {
        given()
                .pathParam("id", 1L)
                .when()
                .delete("/orders/{id}")
                .then()
                .statusCode(204);
    }
}