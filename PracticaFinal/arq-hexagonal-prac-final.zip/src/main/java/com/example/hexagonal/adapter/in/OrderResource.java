package com.example.hexagonal.adapter.in;

import com.example.hexagonal.application.service.OrderService;
import com.example.hexagonal.domain.Orders;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.List;

@Path("/orders")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class OrderResource {

    @Inject
    OrderService orderService;

    @POST
    public Response createOrder(Orders order) {
        Orders createdOrder = orderService.save(order);
        return Response.status(Response.Status.CREATED).entity(createdOrder).build();
    }

    @GET
    @Path("/{id}")
    public Response getOrdersByIdCustomer(@PathParam("id") Long id) {
        List<Orders> orders = orderService.getAllOrdersByIdCustomer(id);
        return Response.ok(orders).build();
    }

    @GET
    public Response getAllOrders() {
        List<Orders> orders = orderService.getAllOrders();
        return Response.ok(orders).build();
    }

    @DELETE
    @Path("/{id}")
    public Response deleteOrder(@PathParam("id") Long id) {
        orderService.deleteOrder(id);
        return Response.noContent().build();
    }
}